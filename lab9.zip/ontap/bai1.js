function sin(number) {
    return Math.sin(number);
}

function cos(number) {
    return Math.cos(number);
}

function tan(number) {
    return Math.tan(number);
}

var number = 45; // Số cần tính toán
console.log("Sin của", number, "là:", sin(number));
console.log("Cosin của", number, "là:", cos(number));
console.log("Tan của", number, "là:", tan(number));
