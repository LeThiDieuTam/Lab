function giaiPhuongTrinhBacHai(a, b, c) {
    var delta = b * b - 4 * a * c;
    var x1, x2;

    if (delta < 0) {
        return "Phương trình vô nghiệm";
    } else if (delta === 0) {
        x1 = -b / (2 * a);
        return "Phương trình có nghiệm kép: x1 = x2 = " + x1;
    } else {
        x1 = (-b + Math.sqrt(delta)) / (2 * a);
        x2 = (-b - Math.sqrt(delta)) / (2 * a);
        return "Nghiệm của phương trình là: x1 = " + x1 + ", x2 = " + x2;
    }
}

var a = parseFloat(prompt("Nhập hệ số a:"));
var b = parseFloat(prompt("Nhập hệ số b:"));
var c = parseFloat(prompt("Nhập hệ số c:"));

var ketQua = giaiPhuongTrinhBacHai(a, b, c);
alert(ketQua);
