function displayConfirmation(){
    var result = confirm("Do you want to display this page?");
    if(result){
        alert("You chose to display the page!");
    }else{
        alert("You chose not to display the page!");
    }
}