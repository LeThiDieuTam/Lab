function giaiPhuongTrinhBacNhat(a, b) {
    if (a === 0) {
        if (b === 0) {
            return "Phương trình vô số nghiệm";
        } else {
            return "Phương trình vô nghiệm";
        }
    } else {
        var x = -b / a;
        return "Nghiệm của phương trình là: x = " + x;
    }
}

var a = parseFloat(prompt("Nhập hệ số a:"));
var b = parseFloat(prompt("Nhập hệ số b:"));

var ketQua = giaiPhuongTrinhBacNhat(a, b);
alert(ketQua);
