var colors = {
    0: "red",
    1: "blue",
    2: "green"
};

for (var index in colors) {
    var color = colors[index];
    
    console.log("Màu tại chỉ số", index, "là:", color);
}
